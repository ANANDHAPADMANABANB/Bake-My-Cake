import { Component, OnInit } from '@angular/core';
import { Cake } from '../models/cake';
import { CakeserviceService } from '../services/cakeservice.service';
import { ActivatedRoute, Router } from '@angular/router';
import { LoginService } from '../userservice/login.service';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-addcakes',
  templateUrl: './addcakes.component.html',
  styleUrl: './addcakes.component.css'
})
export class AddcakesComponent implements OnInit{
    mycakes:Cake={}
    isEditCake:boolean=false;
    constructor(private cakesserv:CakeserviceService,private snackbar:MatSnackBar,private roter:Router,private rs:ActivatedRoute,public logserv:LoginService){}

    ngOnInit(): void {
      this.rs.paramMap.subscribe(params=>{
      let cakeid=params.get("id") ?? 0;
      this.getOneCake(cakeid);
      
      })
    }
  
    getOneCake(id:any){
      this.cakesserv.getCakeById(id).subscribe((data)=>{
        this.mycakes=data;
        this.isEditCake=true
      })
    }


    addNewCake(){
      if(this.isEditCake){
        this.cakesserv.editcake(this.mycakes).subscribe(()=>{
          this.snackbar.open('cake edited successfully','close',{duration:3000,horizontalPosition:'center',verticalPosition:'bottom'});this.roter.navigateByUrl("viewallcakes")
        })
      }
      else{
        this.cakesserv.addCake(this.mycakes).subscribe(()=>{
          this.snackbar.open('cake added successfully','close',{duration:3000,horizontalPosition:'center',verticalPosition:'bottom'});
          this.roter.navigateByUrl("viewallcakes")
          })
      }
    }

    
}
