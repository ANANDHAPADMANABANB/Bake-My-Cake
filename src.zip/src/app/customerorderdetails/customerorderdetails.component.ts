import { Component, OnInit } from '@angular/core';
import { Order } from '../models/order';
import { OrderService } from '../userservice/order.service';


@Component({
  selector: 'app-customerorderdetails',
  templateUrl: './customerorderdetails.component.html',
  styleUrl: './customerorderdetails.component.css'
})
export class CustomerorderdetailsComponent implements OnInit{
    customerorder:Order[]=[]
    

    constructor(private orderserv:OrderService){}
    ngOnInit(): void {
      this.getorderdata()
      
    }
    getorderdata(){
      return this.orderserv.getallorderdetails().subscribe(alldetails =>{
        this.customerorder=alldetails
      })
    }
}
