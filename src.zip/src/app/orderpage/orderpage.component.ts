import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CakeserviceService } from '../services/cakeservice.service';
import { Cake } from '../models/cake';
import { LoginService } from '../userservice/login.service';
import { UserserviceService } from '../userservice/userservice.service';
import { Order } from '../models/order';
import { OrderService } from '../userservice/order.service';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-orderpage',
  templateUrl: './orderpage.component.html',
  styleUrl: './orderpage.component.css'
})
export class OrderpageComponent {
  
  constructor(private rs:ActivatedRoute,private snackbar:MatSnackBar,private orderserv:OrderService,private cakeservs:CakeserviceService,private logserv:LoginService,private userserv:UserserviceService){

  }
  mycakes:Cake={}
  order:Order={
    id:0,
    name:"",
    emailID:"",
    address:"",
    phoneno:"",
    pincode:0,
    deliveryDate:"",
    price:0,
    catagories:"",
    Quantity:0,
    total:0,
    imageurl:"",
    cakemsg:""
  }
  
  
  totalprice=0
 quantity=this.order.Quantity
  ngOnInit(): void {
    this.rs.paramMap.subscribe(params=>{
      let cakeid=params.get("id") ?? 0;
    this.getOneCake(cakeid);
    this.order.emailID=this.logserv.emailiD
    this.order.name=this.logserv.username
    this.order.address=this.logserv.address
    this.order.phoneno=this.logserv.phoneno
    this.order.pincode=this.logserv.pincode
    })
  }

  getOneCake(id:any){
    this.cakeservs.getCakeById(id).subscribe((data)=>{
      this.mycakes=data;
      
    })
  }
  
  

 addplaceorderdetails(){
  if(this.logserv.isUser){
    this.order.catagories=this.mycakes.catagories
    this.order.price=this.mycakes.price
    this.order.imageurl=this.mycakes.imageurl
    
    this.orderserv.addplaceorderdetails(this.order).subscribe(()=>{
    this.snackbar.open('your order got placed successfully','close',{duration:3000,horizontalPosition:'center',verticalPosition:'bottom'});
    
  })
  }
  else{
    this.snackbar.open('Please login','close',{duration:3000,horizontalPosition:'center',verticalPosition:'bottom'});
  }
 }

 minDate(): string {
  const currentDate = new Date();
  const year = currentDate.getFullYear();
  const month = (currentDate.getMonth() + 1).toString().padStart(2, '0');
  const day = currentDate.getDate().toString().padStart(2, '0');
  return `${year}-${month}-${day}`;
}

}
