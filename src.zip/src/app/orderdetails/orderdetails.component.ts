import { Component } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ActivatedRoute } from '@angular/router';

import { LoginService } from '../userservice/login.service';

import { Order } from '../models/order';
import { OrderService } from '../userservice/order.service';

@Component({
  selector: 'app-orderdetails',
  templateUrl: './orderdetails.component.html',
  styleUrl: './orderdetails.component.css'
})
export class OrderdetailsComponent {
  mydetails:Order={}

  constructor(private rs:ActivatedRoute,public logserv:LoginService,private ordersev:OrderService){}
  
  ngOnInit(): void {
    this.rs.paramMap.subscribe(params=>{
      let orderid=params.get("id") ?? 0;
    this.getOnedetails(orderid);
   
    })
  }


  getOnedetails(id:any){
    this.ordersev.getorderById(id).subscribe((data) =>{
      this.mydetails=data
    })
  
  }
}
