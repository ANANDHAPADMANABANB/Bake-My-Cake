import { Component,OnInit} from '@angular/core';
import { Cake } from '../models/cake';
import { ActivatedRoute} from '@angular/router';
import { CakeserviceService } from '../services/cakeservice.service';
import { LoginService } from '../userservice/login.service';
import { Carts } from '../models/cart';
import { UserserviceService } from '../userservice/userservice.service';
import { MatSnackBar } from '@angular/material/snack-bar';


@Component({
  selector: 'app-viewonecake',
  templateUrl: './viewonecake.component.html',
  styleUrl: './viewonecake.component.css'
})
export class ViewonecakeComponent implements OnInit{
  constructor(private snackbar:MatSnackBar,private rs:ActivatedRoute,private cakeservs:CakeserviceService,public logserv:LoginService,private userserv:UserserviceService){}
  mycakes:Cake={}
  
   
  cartuserdetails: Carts = {
    emailiD:"" ,
    cartItems:[{
      cartId:0,
      catagories:"",
      price:0,
      description:""
      }]
  };

  ngOnInit(): void {
    this.rs.paramMap.subscribe(params=>{
      let cakeid=params.get("id") ?? 0;
    this.getOneCake(cakeid);
    })
  }

  getOneCake(id:any){
    this.cakeservs.getCakeById(id).subscribe((data)=>{
      this.mycakes=data;
    })
  }
  
  addCart() {
    const emailid = this.logserv.emailiD;
    const newItem= {
      cartId: this.mycakes.id,
      catagories: this.mycakes.catagories,
      price: this.mycakes.price,
      description: this.mycakes.description
    };

    this.cakeservs.getcartdetails().subscribe((data) => {
      if (data.length === 0) {
        this.cartuserdetails.emailiD = emailid;
        this.cartuserdetails.cartItems = [newItem];
        this.cakeservs.addCart(this.cartuserdetails).subscribe(() => {
          this.snackbar.open('Successfully Added', 'Close');
        });
      } else {
        this.cakeservs.checkuserexist(emailid).subscribe(existingCart => {
          if (existingCart.emailiD === this.logserv.emailiD) {
            existingCart.cartItems.push(newItem);
            this.cakeservs.updateCart(existingCart).subscribe(() => {
              this.snackbar.open('Successfully Updated', 'Close');
            });
          } else {
            this.cartuserdetails.emailiD = emailid;
            this.cartuserdetails.cartItems = [newItem];
            this.cakeservs.addCart(this.cartuserdetails).subscribe(() => {
              this.snackbar.open('Successfully Added new', 'Close');
            });
          }
        });
      }
    });
  }
}
