export type Carts = {
     
    emailiD?: string;
    cartItems:[{
      cartId?:number;
      imageurl?:string;
      catagories?: string;
      price?: number;
      description?:string;
      }];
    
  };